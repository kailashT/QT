/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QStackedWidget *stackedWidget;
    QWidget *Welcome;
    QGridLayout *gridLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout_12;
    QLabel *Date;
    QSpacerItem *horizontalSpacer;
    QLabel *Time;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_14;
    QPushButton *btn_add_user;
    QHBoxLayout *horizontalLayout_15;
    QPushButton *btn_daily_data;
    QHBoxLayout *horizontalLayout_16;
    QPushButton *btn_overview;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *Session_Exit;
    QSpacerItem *verticalSpacer;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *horizontalSpacer_2;
    QWidget *Add_User;
    QGridLayout *gridLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_16;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer_15;
    QLineEdit *User_mo1;
    QSpacerItem *horizontalSpacer_12;
    QSpacerItem *verticalSpacer_9;
    QHBoxLayout *horizontalLayout_23;
    QSpacerItem *horizontalSpacer_43;
    QLabel *label_13;
    QSpacerItem *horizontalSpacer_44;
    QLineEdit *To_pay;
    QSpacerItem *horizontalSpacer_45;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_8;
    QLabel *label;
    QSpacerItem *horizontalSpacer_7;
    QLineEdit *User_name;
    QSpacerItem *horizontalSpacer_9;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_14;
    QLabel *label_4;
    QSpacerItem *horizontalSpacer_6;
    QLineEdit *User_mo2;
    QSpacerItem *horizontalSpacer_19;
    QSpacerItem *verticalSpacer_13;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_11;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_13;
    QLineEdit *User_address;
    QSpacerItem *horizontalSpacer_10;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *horizontalLayout_18;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_6;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_17;
    QSpacerItem *horizontalSpacer_22;
    QComboBox *Select_Action;
    QSpacerItem *horizontalSpacer_23;
    QPushButton *Save_Data;
    QSpacerItem *horizontalSpacer_21;
    QSpacerItem *verticalSpacer_7;
    QSpacerItem *verticalSpacer_8;
    QHBoxLayout *horizontalLayout_19;
    QPushButton *Destroy_session;
    QSpacerItem *horizontalSpacer_24;
    QSpacerItem *verticalSpacer_12;
    QSpacerItem *verticalSpacer_11;
    QHBoxLayout *horizontalLayout_7;
    QSpacerItem *horizontalSpacer_20;
    QLabel *label_5;
    QSpacerItem *horizontalSpacer_18;
    QLineEdit *User_price;
    QSpacerItem *horizontalSpacer_17;
    QSpacerItem *verticalSpacer_6;
    QSpacerItem *verticalSpacer_10;
    QWidget *Daily_Stat;
    QGridLayout *gridLayout_4;
    QVBoxLayout *verticalLayout_4;
    QSpacerItem *verticalSpacer_17;
    QHBoxLayout *horizontalLayout_21;
    QSpacerItem *horizontalSpacer_26;
    QDateEdit *Set_date;
    QSpacerItem *horizontalSpacer_27;
    QSpacerItem *verticalSpacer_18;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_28;
    QLabel *label_7;
    QSpacerItem *horizontalSpacer_30;
    QLineEdit *Value_name;
    QSpacerItem *horizontalSpacer_29;
    QSpacerItem *verticalSpacer_19;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_31;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_37;
    QLineEdit *value_taken;
    QSpacerItem *horizontalSpacer_36;
    QSpacerItem *verticalSpacer_20;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_38;
    QLabel *label_9;
    QSpacerItem *horizontalSpacer_35;
    QLineEdit *value_return;
    QSpacerItem *horizontalSpacer_42;
    QSpacerItem *verticalSpacer_22;
    QHBoxLayout *horizontalLayout_9;
    QSpacerItem *horizontalSpacer_39;
    QLabel *label_10;
    QSpacerItem *horizontalSpacer_41;
    QLineEdit *value_money;
    QSpacerItem *horizontalSpacer_40;
    QSpacerItem *verticalSpacer_21;
    QHBoxLayout *horizontalLayout_22;
    QSpacerItem *horizontalSpacer_34;
    QComboBox *SU_Record;
    QSpacerItem *horizontalSpacer_33;
    QPushButton *Save_daily_data;
    QSpacerItem *horizontalSpacer_32;
    QSpacerItem *verticalSpacer_23;
    QHBoxLayout *horizontalLayout_20;
    QPushButton *Destroy_session_2;
    QSpacerItem *horizontalSpacer_25;
    QSpacerItem *verticalSpacer_24;
    QWidget *Overview;
    QGridLayout *gridLayout_5;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *verticalSpacer_16;
    QHBoxLayout *horizontalLayout_25;
    QComboBox *SAFSD;
    QSpacerItem *horizontalSpacer_46;
    QPushButton *btn_back;
    QSpacerItem *verticalSpacer_15;
    QHBoxLayout *horizontalLayout_11;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer_48;
    QLabel *label_11;
    QLineEdit *Search_name;
    QSpacerItem *horizontalSpacer_47;
    QDateEdit *Date_Show;
    QPushButton *Show_details;
    QSpacerItem *verticalSpacer_14;
    QHBoxLayout *horizontalLayout_24;
    QTableWidget *Info_table;
    QSpacerItem *verticalSpacer_25;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(436, 475);
        QIcon icon;
        icon.addFile(QStringLiteral("images/project_logo_icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        centralWidget->setStyleSheet(QStringLiteral(" background-color:rgb(189, 205, 255)"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        stackedWidget->setFont(font);
        stackedWidget->setLayoutDirection(Qt::LeftToRight);
        stackedWidget->setAutoFillBackground(false);
        stackedWidget->setStyleSheet(QStringLiteral(" background-color:rgb(219, 255, 249)"));
        Welcome = new QWidget();
        Welcome->setObjectName(QStringLiteral("Welcome"));
        gridLayout_2 = new QGridLayout(Welcome);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_3, 1, 2, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(6, 6, 6, 6);
        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(6, 6, 6, 6);
        Date = new QLabel(Welcome);
        Date->setObjectName(QStringLiteral("Date"));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        Date->setFont(font1);

        horizontalLayout_12->addWidget(Date);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer);

        Time = new QLabel(Welcome);
        Time->setObjectName(QStringLiteral("Time"));
        Time->setFont(font1);

        horizontalLayout_12->addWidget(Time);


        verticalLayout->addLayout(horizontalLayout_12);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(6, 6, 6, 6);
        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(6, 6, 6, 6);
        btn_add_user = new QPushButton(Welcome);
        btn_add_user->setObjectName(QStringLiteral("btn_add_user"));
        btn_add_user->setMaximumSize(QSize(200, 16777215));
        QFont font2;
        font2.setBold(true);
        font2.setWeight(75);
        btn_add_user->setFont(font2);
        btn_add_user->setLayoutDirection(Qt::LeftToRight);

        horizontalLayout_14->addWidget(btn_add_user);


        verticalLayout_2->addLayout(horizontalLayout_14);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        horizontalLayout_15->setContentsMargins(6, 6, 6, 6);
        btn_daily_data = new QPushButton(Welcome);
        btn_daily_data->setObjectName(QStringLiteral("btn_daily_data"));
        btn_daily_data->setMaximumSize(QSize(200, 16777215));
        btn_daily_data->setFont(font2);
        btn_daily_data->setLayoutDirection(Qt::LeftToRight);

        horizontalLayout_15->addWidget(btn_daily_data);


        verticalLayout_2->addLayout(horizontalLayout_15);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        horizontalLayout_16->setContentsMargins(6, 6, 6, 6);
        btn_overview = new QPushButton(Welcome);
        btn_overview->setObjectName(QStringLiteral("btn_overview"));
        btn_overview->setMaximumSize(QSize(200, 16777215));
        btn_overview->setFont(font2);

        horizontalLayout_16->addWidget(btn_overview);


        verticalLayout_2->addLayout(horizontalLayout_16);


        verticalLayout->addLayout(verticalLayout_2);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        horizontalLayout_13->setContentsMargins(6, 6, 6, 6);
        Session_Exit = new QPushButton(Welcome);
        Session_Exit->setObjectName(QStringLiteral("Session_Exit"));
        Session_Exit->setMaximumSize(QSize(200, 16777215));
        Session_Exit->setFont(font2);

        horizontalLayout_13->addWidget(Session_Exit);


        verticalLayout->addLayout(horizontalLayout_13);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        gridLayout_2->addLayout(verticalLayout, 1, 1, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_3, 2, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_2, 0, 1, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_2, 1, 0, 1, 1);

        stackedWidget->addWidget(Welcome);
        Add_User = new QWidget();
        Add_User->setObjectName(QStringLiteral("Add_User"));
        gridLayout_3 = new QGridLayout(Add_User);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_16 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_16);

        label_3 = new QLabel(Add_User);
        label_3->setObjectName(QStringLiteral("label_3"));
        sizePolicy.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy);
        label_3->setAutoFillBackground(false);
        label_3->setScaledContents(true);

        horizontalLayout_5->addWidget(label_3);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_15);

        User_mo1 = new QLineEdit(Add_User);
        User_mo1->setObjectName(QStringLiteral("User_mo1"));
        User_mo1->setAutoFillBackground(false);
        User_mo1->setInputMethodHints(Qt::ImhDigitsOnly);

        horizontalLayout_5->addWidget(User_mo1);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_12);


        gridLayout_3->addLayout(horizontalLayout_5, 7, 0, 1, 1);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_9, 8, 0, 1, 1);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        horizontalLayout_23->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_43 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_43);

        label_13 = new QLabel(Add_User);
        label_13->setObjectName(QStringLiteral("label_13"));
        sizePolicy.setHeightForWidth(label_13->sizePolicy().hasHeightForWidth());
        label_13->setSizePolicy(sizePolicy);
        label_13->setAutoFillBackground(false);
        label_13->setScaledContents(true);

        horizontalLayout_23->addWidget(label_13);

        horizontalSpacer_44 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_44);

        To_pay = new QLineEdit(Add_User);
        To_pay->setObjectName(QStringLiteral("To_pay"));
        To_pay->setAutoFillBackground(false);
        To_pay->setInputMethodHints(Qt::ImhDigitsOnly);

        horizontalLayout_23->addWidget(To_pay);

        horizontalSpacer_45 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_23->addItem(horizontalSpacer_45);


        gridLayout_3->addLayout(horizontalLayout_23, 13, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_8);

        label = new QLabel(Add_User);
        label->setObjectName(QStringLiteral("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setAutoFillBackground(false);
        label->setScaledContents(true);

        horizontalLayout->addWidget(label);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_7);

        User_name = new QLineEdit(Add_User);
        User_name->setObjectName(QStringLiteral("User_name"));
        User_name->setAutoFillBackground(false);
        User_name->setInputMethodHints(Qt::ImhLatinOnly);

        horizontalLayout->addWidget(User_name);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_9);


        gridLayout_3->addLayout(horizontalLayout, 3, 0, 1, 1);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_14);

        label_4 = new QLabel(Add_User);
        label_4->setObjectName(QStringLiteral("label_4"));
        sizePolicy.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy);
        label_4->setAutoFillBackground(false);
        label_4->setScaledContents(true);

        horizontalLayout_6->addWidget(label_4);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_6);

        User_mo2 = new QLineEdit(Add_User);
        User_mo2->setObjectName(QStringLiteral("User_mo2"));
        User_mo2->setAutoFillBackground(false);
        User_mo2->setInputMethodHints(Qt::ImhDigitsOnly);

        horizontalLayout_6->addWidget(User_mo2);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_19);


        gridLayout_3->addLayout(horizontalLayout_6, 9, 0, 1, 1);

        verticalSpacer_13 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_13, 16, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_11);

        label_2 = new QLabel(Add_User);
        label_2->setObjectName(QStringLiteral("label_2"));
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        label_2->setAutoFillBackground(false);
        label_2->setScaledContents(true);

        horizontalLayout_2->addWidget(label_2);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_13);

        User_address = new QLineEdit(Add_User);
        User_address->setObjectName(QStringLiteral("User_address"));
        User_address->setAutoFillBackground(false);

        horizontalLayout_2->addWidget(User_address);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_10);


        gridLayout_3->addLayout(horizontalLayout_2, 5, 0, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_5, 0, 0, 1, 1);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        horizontalLayout_18->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_5);

        label_6 = new QLabel(Add_User);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setAlignment(Qt::AlignCenter);

        horizontalLayout_18->addWidget(label_6);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_18->addItem(horizontalSpacer_4);


        gridLayout_3->addLayout(horizontalLayout_18, 1, 0, 1, 1);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        horizontalLayout_17->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_22);

        Select_Action = new QComboBox(Add_User);
        Select_Action->addItem(QString());
        Select_Action->addItem(QString());
        Select_Action->addItem(QString());
        Select_Action->setObjectName(QStringLiteral("Select_Action"));

        horizontalLayout_17->addWidget(Select_Action);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_23);

        Save_Data = new QPushButton(Add_User);
        Save_Data->setObjectName(QStringLiteral("Save_Data"));
        Save_Data->setAutoFillBackground(false);

        horizontalLayout_17->addWidget(Save_Data);

        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_21);


        gridLayout_3->addLayout(horizontalLayout_17, 15, 0, 1, 1);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_7, 4, 0, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_8, 6, 0, 1, 1);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        Destroy_session = new QPushButton(Add_User);
        Destroy_session->setObjectName(QStringLiteral("Destroy_session"));

        horizontalLayout_19->addWidget(Destroy_session);

        horizontalSpacer_24 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_19->addItem(horizontalSpacer_24);


        gridLayout_3->addLayout(horizontalLayout_19, 17, 0, 1, 1);

        verticalSpacer_12 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_12, 14, 0, 1, 1);

        verticalSpacer_11 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_11, 12, 0, 1, 1);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_20);

        label_5 = new QLabel(Add_User);
        label_5->setObjectName(QStringLiteral("label_5"));
        sizePolicy.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy);
        label_5->setAutoFillBackground(false);
        label_5->setScaledContents(true);

        horizontalLayout_7->addWidget(label_5);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_18);

        User_price = new QLineEdit(Add_User);
        User_price->setObjectName(QStringLiteral("User_price"));
        User_price->setAutoFillBackground(false);
        User_price->setInputMethodHints(Qt::ImhDigitsOnly);

        horizontalLayout_7->addWidget(User_price);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_17);


        gridLayout_3->addLayout(horizontalLayout_7, 11, 0, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_6, 2, 0, 1, 1);

        verticalSpacer_10 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_10, 10, 0, 1, 1);

        stackedWidget->addWidget(Add_User);
        Daily_Stat = new QWidget();
        Daily_Stat->setObjectName(QStringLiteral("Daily_Stat"));
        sizePolicy.setHeightForWidth(Daily_Stat->sizePolicy().hasHeightForWidth());
        Daily_Stat->setSizePolicy(sizePolicy);
        Daily_Stat->setAutoFillBackground(false);
        gridLayout_4 = new QGridLayout(Daily_Stat);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(6, 6, 6, 6);
        verticalSpacer_17 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_17);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        horizontalLayout_21->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_26 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_26);

        Set_date = new QDateEdit(Daily_Stat);
        Set_date->setObjectName(QStringLiteral("Set_date"));
        QFont font3;
        font3.setPointSize(15);
        Set_date->setFont(font3);
        Set_date->setCalendarPopup(true);

        horizontalLayout_21->addWidget(Set_date);

        horizontalSpacer_27 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_21->addItem(horizontalSpacer_27);


        verticalLayout_4->addLayout(horizontalLayout_21);

        verticalSpacer_18 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_18);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_28 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_28);

        label_7 = new QLabel(Daily_Stat);
        label_7->setObjectName(QStringLiteral("label_7"));
        sizePolicy.setHeightForWidth(label_7->sizePolicy().hasHeightForWidth());
        label_7->setSizePolicy(sizePolicy);
        label_7->setFont(font2);
        label_7->setAutoFillBackground(false);
        label_7->setScaledContents(true);

        horizontalLayout_3->addWidget(label_7);

        horizontalSpacer_30 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_30);

        Value_name = new QLineEdit(Daily_Stat);
        Value_name->setObjectName(QStringLiteral("Value_name"));
        QFont font4;
        font4.setBold(false);
        font4.setWeight(50);
        Value_name->setFont(font4);
        Value_name->setAutoFillBackground(false);
        Value_name->setInputMethodHints(Qt::ImhLatinOnly);

        horizontalLayout_3->addWidget(Value_name);

        horizontalSpacer_29 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_29);


        verticalLayout_4->addLayout(horizontalLayout_3);

        verticalSpacer_19 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_19);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_31 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_31);

        label_8 = new QLabel(Daily_Stat);
        label_8->setObjectName(QStringLiteral("label_8"));
        sizePolicy.setHeightForWidth(label_8->sizePolicy().hasHeightForWidth());
        label_8->setSizePolicy(sizePolicy);
        label_8->setFont(font2);
        label_8->setAutoFillBackground(false);
        label_8->setScaledContents(true);

        horizontalLayout_4->addWidget(label_8);

        horizontalSpacer_37 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_37);

        value_taken = new QLineEdit(Daily_Stat);
        value_taken->setObjectName(QStringLiteral("value_taken"));
        QFont font5;
        font5.setBold(false);
        font5.setUnderline(false);
        font5.setWeight(50);
        value_taken->setFont(font5);
        value_taken->setAutoFillBackground(false);
        value_taken->setInputMethodHints(Qt::ImhDigitsOnly);
        value_taken->setDragEnabled(false);

        horizontalLayout_4->addWidget(value_taken);

        horizontalSpacer_36 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_36);


        verticalLayout_4->addLayout(horizontalLayout_4);

        verticalSpacer_20 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_20);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_38 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_38);

        label_9 = new QLabel(Daily_Stat);
        label_9->setObjectName(QStringLiteral("label_9"));
        sizePolicy.setHeightForWidth(label_9->sizePolicy().hasHeightForWidth());
        label_9->setSizePolicy(sizePolicy);
        label_9->setFont(font2);
        label_9->setAutoFillBackground(false);
        label_9->setScaledContents(true);

        horizontalLayout_8->addWidget(label_9);

        horizontalSpacer_35 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_35);

        value_return = new QLineEdit(Daily_Stat);
        value_return->setObjectName(QStringLiteral("value_return"));
        value_return->setFont(font4);
        value_return->setAutoFillBackground(false);
        value_return->setInputMethodHints(Qt::ImhDigitsOnly);

        horizontalLayout_8->addWidget(value_return);

        horizontalSpacer_42 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_42);


        verticalLayout_4->addLayout(horizontalLayout_8);

        verticalSpacer_22 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_22);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_39 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_39);

        label_10 = new QLabel(Daily_Stat);
        label_10->setObjectName(QStringLiteral("label_10"));
        sizePolicy.setHeightForWidth(label_10->sizePolicy().hasHeightForWidth());
        label_10->setSizePolicy(sizePolicy);
        label_10->setFont(font2);
        label_10->setAutoFillBackground(false);
        label_10->setScaledContents(true);

        horizontalLayout_9->addWidget(label_10);

        horizontalSpacer_41 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_41);

        value_money = new QLineEdit(Daily_Stat);
        value_money->setObjectName(QStringLiteral("value_money"));
        value_money->setFont(font4);
        value_money->setAutoFillBackground(false);
        value_money->setInputMethodHints(Qt::ImhDigitsOnly);

        horizontalLayout_9->addWidget(value_money);

        horizontalSpacer_40 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_40);


        verticalLayout_4->addLayout(horizontalLayout_9);

        verticalSpacer_21 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_21);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        horizontalLayout_22->setContentsMargins(6, 6, 6, 6);
        horizontalSpacer_34 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_34);

        SU_Record = new QComboBox(Daily_Stat);
        SU_Record->addItem(QString());
        SU_Record->addItem(QString());
        SU_Record->setObjectName(QStringLiteral("SU_Record"));
        SU_Record->setFont(font2);

        horizontalLayout_22->addWidget(SU_Record);

        horizontalSpacer_33 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_33);

        Save_daily_data = new QPushButton(Daily_Stat);
        Save_daily_data->setObjectName(QStringLiteral("Save_daily_data"));
        Save_daily_data->setFont(font2);

        horizontalLayout_22->addWidget(Save_daily_data);

        horizontalSpacer_32 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_32);


        verticalLayout_4->addLayout(horizontalLayout_22);

        verticalSpacer_23 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_23);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        horizontalLayout_20->setContentsMargins(6, 6, 6, 6);
        Destroy_session_2 = new QPushButton(Daily_Stat);
        Destroy_session_2->setObjectName(QStringLiteral("Destroy_session_2"));

        horizontalLayout_20->addWidget(Destroy_session_2);

        horizontalSpacer_25 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_20->addItem(horizontalSpacer_25);


        verticalLayout_4->addLayout(horizontalLayout_20);

        verticalSpacer_24 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_24);


        gridLayout_4->addLayout(verticalLayout_4, 0, 0, 1, 1);

        stackedWidget->addWidget(Daily_Stat);
        Overview = new QWidget();
        Overview->setObjectName(QStringLiteral("Overview"));
        gridLayout_5 = new QGridLayout(Overview);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(6, 6, 6, 6);
        verticalSpacer_16 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_16);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        SAFSD = new QComboBox(Overview);
        SAFSD->addItem(QString());
        SAFSD->addItem(QString());
        SAFSD->addItem(QString());
        SAFSD->addItem(QString());
        SAFSD->addItem(QString());
        SAFSD->addItem(QString());
        SAFSD->addItem(QString());
        SAFSD->setObjectName(QStringLiteral("SAFSD"));

        horizontalLayout_25->addWidget(SAFSD);

        horizontalSpacer_46 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_46);

        btn_back = new QPushButton(Overview);
        btn_back->setObjectName(QStringLiteral("btn_back"));

        horizontalLayout_25->addWidget(btn_back);


        verticalLayout_3->addLayout(horizontalLayout_25);

        verticalSpacer_15 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_15);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        horizontalSpacer_48 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_48);

        label_11 = new QLabel(Overview);
        label_11->setObjectName(QStringLiteral("label_11"));
        sizePolicy.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy);
        label_11->setAutoFillBackground(false);
        label_11->setScaledContents(true);

        horizontalLayout_10->addWidget(label_11);

        Search_name = new QLineEdit(Overview);
        Search_name->setObjectName(QStringLiteral("Search_name"));
        Search_name->setAutoFillBackground(false);

        horizontalLayout_10->addWidget(Search_name);

        horizontalSpacer_47 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_47);


        horizontalLayout_11->addLayout(horizontalLayout_10);

        Date_Show = new QDateEdit(Overview);
        Date_Show->setObjectName(QStringLiteral("Date_Show"));
        QFont font6;
        font6.setPointSize(20);
        font6.setBold(false);
        font6.setWeight(50);
        Date_Show->setFont(font6);
        Date_Show->setCalendarPopup(true);

        horizontalLayout_11->addWidget(Date_Show);

        Show_details = new QPushButton(Overview);
        Show_details->setObjectName(QStringLiteral("Show_details"));

        horizontalLayout_11->addWidget(Show_details);


        verticalLayout_3->addLayout(horizontalLayout_11);

        verticalSpacer_14 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_14);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        horizontalLayout_24->setContentsMargins(6, 6, 6, 6);
        Info_table = new QTableWidget(Overview);
        Info_table->setObjectName(QStringLiteral("Info_table"));
        Info_table->setAutoFillBackground(true);
        Info_table->setLineWidth(2);
        Info_table->setMidLineWidth(2);
        Info_table->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        Info_table->setAlternatingRowColors(true);
        Info_table->setRowCount(0);
        Info_table->horizontalHeader()->setCascadingSectionResizes(true);
        Info_table->verticalHeader()->setStretchLastSection(false);

        horizontalLayout_24->addWidget(Info_table);


        verticalLayout_3->addLayout(horizontalLayout_24);

        verticalSpacer_25 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_25);


        gridLayout_5->addLayout(verticalLayout_3, 0, 0, 1, 1);

        stackedWidget->addWidget(Overview);

        gridLayout->addWidget(stackedWidget, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 436, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(btn_add_user, btn_daily_data);
        QWidget::setTabOrder(btn_daily_data, btn_overview);
        QWidget::setTabOrder(btn_overview, Session_Exit);
        QWidget::setTabOrder(Session_Exit, User_name);
        QWidget::setTabOrder(User_name, User_address);
        QWidget::setTabOrder(User_address, User_mo1);
        QWidget::setTabOrder(User_mo1, User_mo2);
        QWidget::setTabOrder(User_mo2, User_price);
        QWidget::setTabOrder(User_price, To_pay);
        QWidget::setTabOrder(To_pay, Save_Data);
        QWidget::setTabOrder(Save_Data, Destroy_session);
        QWidget::setTabOrder(Destroy_session, Set_date);
        QWidget::setTabOrder(Set_date, Value_name);
        QWidget::setTabOrder(Value_name, value_taken);
        QWidget::setTabOrder(value_taken, value_return);
        QWidget::setTabOrder(value_return, value_money);
        QWidget::setTabOrder(value_money, SU_Record);
        QWidget::setTabOrder(SU_Record, Save_daily_data);
        QWidget::setTabOrder(Save_daily_data, Destroy_session_2);
        QWidget::setTabOrder(Destroy_session_2, btn_back);
        QWidget::setTabOrder(btn_back, Search_name);
        QWidget::setTabOrder(Search_name, Show_details);
        QWidget::setTabOrder(Show_details, Date_Show);
        QWidget::setTabOrder(Date_Show, Select_Action);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Project QT ", nullptr));
        Date->setText(QApplication::translate("MainWindow", "Date", nullptr));
        Time->setText(QApplication::translate("MainWindow", "Time", nullptr));
        btn_add_user->setText(QApplication::translate("MainWindow", "Add User", nullptr));
        btn_daily_data->setText(QApplication::translate("MainWindow", "Daily_Data", nullptr));
        btn_overview->setText(QApplication::translate("MainWindow", "Overview", nullptr));
        Session_Exit->setText(QApplication::translate("MainWindow", "Exit", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Mo. No1* :", nullptr));
        label_13->setText(QApplication::translate("MainWindow", "To_Pay   :", nullptr));
        label->setText(QApplication::translate("MainWindow", "Name* :", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Mo. No2 :", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Address :", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "INFORMATION", nullptr));
        Select_Action->setItemText(0, QApplication::translate("MainWindow", "Add", nullptr));
        Select_Action->setItemText(1, QApplication::translate("MainWindow", "Update", nullptr));
        Select_Action->setItemText(2, QApplication::translate("MainWindow", "Delete", nullptr));

        Save_Data->setText(QApplication::translate("MainWindow", "Save ", nullptr));
        Destroy_session->setText(QApplication::translate("MainWindow", "Home", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Price* :", nullptr));
        Set_date->setDisplayFormat(QApplication::translate("MainWindow", "dd/MM/yyyy", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "Name :", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "Taken :", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "Return :", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "Money :", nullptr));
        SU_Record->setItemText(0, QApplication::translate("MainWindow", "Save Record", nullptr));
        SU_Record->setItemText(1, QApplication::translate("MainWindow", "Update Record", nullptr));

        Save_daily_data->setText(QApplication::translate("MainWindow", "Save", nullptr));
        Destroy_session_2->setText(QApplication::translate("MainWindow", "Home", nullptr));
        SAFSD->setItemText(0, QApplication::translate("MainWindow", "Data For Single Date", nullptr));
        SAFSD->setItemText(1, QApplication::translate("MainWindow", "Customer Monthly Data", nullptr));
        SAFSD->setItemText(2, QApplication::translate("MainWindow", "Customer Monthly Report", nullptr));
        SAFSD->setItemText(3, QApplication::translate("MainWindow", "Monthly report", nullptr));
        SAFSD->setItemText(4, QApplication::translate("MainWindow", "Customer Information", nullptr));
        SAFSD->setItemText(5, QApplication::translate("MainWindow", "Sync For Customer", nullptr));
        SAFSD->setItemText(6, QApplication::translate("MainWindow", "Sync For All", nullptr));

        btn_back->setText(QApplication::translate("MainWindow", "Home", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "Name :", nullptr));
        Date_Show->setDisplayFormat(QApplication::translate("MainWindow", "dd/MM/yyyy", nullptr));
        Show_details->setText(QApplication::translate("MainWindow", "Show Details", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
