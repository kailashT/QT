/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[26];
    char stringdata0[584];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 26), // "on_Save_daily_data_clicked"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 23), // "on_btn_add_user_clicked"
QT_MOC_LITERAL(4, 63, 25), // "on_btn_daily_data_clicked"
QT_MOC_LITERAL(5, 89, 19), // "on_btn_back_clicked"
QT_MOC_LITERAL(6, 109, 10), // "UpdateTime"
QT_MOC_LITERAL(7, 120, 23), // "on_btn_overview_clicked"
QT_MOC_LITERAL(8, 144, 23), // "on_btn_add_user_pressed"
QT_MOC_LITERAL(9, 168, 26), // "on_Destroy_session_clicked"
QT_MOC_LITERAL(10, 195, 23), // "on_Show_details_clicked"
QT_MOC_LITERAL(11, 219, 23), // "on_Session_Exit_clicked"
QT_MOC_LITERAL(12, 243, 28), // "on_Destroy_session_2_clicked"
QT_MOC_LITERAL(13, 272, 20), // "on_testcombo_clicked"
QT_MOC_LITERAL(14, 293, 20), // "on_Save_Data_clicked"
QT_MOC_LITERAL(15, 314, 18), // "check_for_database"
QT_MOC_LITERAL(16, 333, 36), // "on_Select_Action_currentIndex..."
QT_MOC_LITERAL(17, 370, 4), // "arg1"
QT_MOC_LITERAL(18, 375, 32), // "on_SU_Record_currentIndexChanged"
QT_MOC_LITERAL(19, 408, 28), // "on_SAFSD_currentIndexChanged"
QT_MOC_LITERAL(20, 437, 33), // "Update_Query_For_Daily_data_T..."
QT_MOC_LITERAL(21, 471, 33), // "Insart_Query_For_Daily_data_T..."
QT_MOC_LITERAL(22, 505, 21), // "sync_data_for_a_month"
QT_MOC_LITERAL(23, 527, 19), // "Sync_For_A_Customer"
QT_MOC_LITERAL(24, 547, 16), // "Delete_Table_row"
QT_MOC_LITERAL(25, 564, 19) // "Delete_Table_Column"

    },
    "MainWindow\0on_Save_daily_data_clicked\0"
    "\0on_btn_add_user_clicked\0"
    "on_btn_daily_data_clicked\0on_btn_back_clicked\0"
    "UpdateTime\0on_btn_overview_clicked\0"
    "on_btn_add_user_pressed\0"
    "on_Destroy_session_clicked\0"
    "on_Show_details_clicked\0on_Session_Exit_clicked\0"
    "on_Destroy_session_2_clicked\0"
    "on_testcombo_clicked\0on_Save_Data_clicked\0"
    "check_for_database\0"
    "on_Select_Action_currentIndexChanged\0"
    "arg1\0on_SU_Record_currentIndexChanged\0"
    "on_SAFSD_currentIndexChanged\0"
    "Update_Query_For_Daily_data_Table\0"
    "Insart_Query_For_Daily_data_Table\0"
    "sync_data_for_a_month\0Sync_For_A_Customer\0"
    "Delete_Table_row\0Delete_Table_Column"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x08 /* Private */,
       3,    0,  130,    2, 0x08 /* Private */,
       4,    0,  131,    2, 0x08 /* Private */,
       5,    0,  132,    2, 0x08 /* Private */,
       6,    0,  133,    2, 0x08 /* Private */,
       7,    0,  134,    2, 0x08 /* Private */,
       8,    0,  135,    2, 0x08 /* Private */,
       9,    0,  136,    2, 0x08 /* Private */,
      10,    0,  137,    2, 0x08 /* Private */,
      11,    0,  138,    2, 0x08 /* Private */,
      12,    0,  139,    2, 0x08 /* Private */,
      13,    0,  140,    2, 0x08 /* Private */,
      14,    0,  141,    2, 0x08 /* Private */,
      15,    0,  142,    2, 0x08 /* Private */,
      16,    1,  143,    2, 0x08 /* Private */,
      18,    1,  146,    2, 0x08 /* Private */,
      19,    1,  149,    2, 0x08 /* Private */,
      20,    0,  152,    2, 0x08 /* Private */,
      21,    0,  153,    2, 0x08 /* Private */,
      22,    2,  154,    2, 0x08 /* Private */,
      23,    2,  159,    2, 0x08 /* Private */,
      24,    0,  164,    2, 0x08 /* Private */,
      25,    0,  165,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Int, QMetaType::QString, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    2,    2,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_Save_daily_data_clicked(); break;
        case 1: _t->on_btn_add_user_clicked(); break;
        case 2: _t->on_btn_daily_data_clicked(); break;
        case 3: _t->on_btn_back_clicked(); break;
        case 4: _t->UpdateTime(); break;
        case 5: _t->on_btn_overview_clicked(); break;
        case 6: _t->on_btn_add_user_pressed(); break;
        case 7: _t->on_Destroy_session_clicked(); break;
        case 8: _t->on_Show_details_clicked(); break;
        case 9: _t->on_Session_Exit_clicked(); break;
        case 10: _t->on_Destroy_session_2_clicked(); break;
        case 11: _t->on_testcombo_clicked(); break;
        case 12: _t->on_Save_Data_clicked(); break;
        case 13: _t->check_for_database(); break;
        case 14: _t->on_Select_Action_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->on_SU_Record_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->on_SAFSD_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: { QString _r = _t->Update_Query_For_Daily_data_Table();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 18: { QString _r = _t->Insart_Query_For_Daily_data_Table();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 19: { int _r = _t->sync_data_for_a_month((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 20: _t->Sync_For_A_Customer((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 21: _t->Delete_Table_row(); break;
        case 22: _t->Delete_Table_Column(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
